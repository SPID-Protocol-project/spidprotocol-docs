export default [
  require("/workspaces/spidprotocol-docs/node_modules/infima/dist/css/default/default.css"),
  require("/workspaces/spidprotocol-docs/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/workspaces/spidprotocol-docs/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/workspaces/spidprotocol-docs/src/css/custom.css"),
];
